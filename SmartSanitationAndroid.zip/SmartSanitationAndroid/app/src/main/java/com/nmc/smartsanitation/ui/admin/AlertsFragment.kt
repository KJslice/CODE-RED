package com.nmc.smartsanitation.ui.admin

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.nmc.smartsanitation.api.RetrofitClient
import com.nmc.smartsanitation.api.models.Alert
import com.nmc.smartsanitation.databinding.FragmentAlertsBinding
import com.nmc.smartsanitation.databinding.ItemAlertBinding
import com.nmc.smartsanitation.utils.SessionManager
import com.nmc.smartsanitation.utils.hide
import com.nmc.smartsanitation.utils.show
import com.nmc.smartsanitation.utils.toast
import kotlinx.coroutines.launch

class AlertsFragment : Fragment() {

    private var _binding: FragmentAlertsBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: AlertAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAlertsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = AlertAdapter { alert -> resolveAlert(alert) }
        binding.rvAlerts.layoutManager = LinearLayoutManager(requireContext())
        binding.rvAlerts.adapter = adapter

        binding.swipeRefresh.setOnRefreshListener { loadAlerts() }
        loadAlerts()
    }

    private fun loadAlerts() {
        binding.progressBar.show()
        lifecycleScope.launch {
            try {
                val token = SessionManager.getBearerToken(requireContext())
                val response = RetrofitClient.apiService.getAlerts(token)
                binding.progressBar.hide()
                binding.swipeRefresh.isRefreshing = false
                if (response.isSuccessful) {
                    val alerts = response.body()?.alerts ?: emptyList()
                    adapter.submitList(alerts)
                    binding.tvCount.text = "${alerts.size} active alert(s)"
                    if (alerts.isEmpty()) binding.tvEmpty.show() else binding.tvEmpty.hide()
                } else {
                    requireContext().toast("Failed to load alerts")
                }
            } catch (e: Exception) {
                binding.progressBar.hide()
                binding.swipeRefresh.isRefreshing = false
                requireContext().toast("Error: ${e.localizedMessage}")
            }
        }
    }

    private fun resolveAlert(alert: Alert) {
        lifecycleScope.launch {
            try {
                val token = SessionManager.getBearerToken(requireContext())
                val response = RetrofitClient.apiService.resolveAlert(token, alert.id)
                if (response.isSuccessful) {
                    requireContext().toast("✅ Alert resolved")
                    loadAlerts()
                } else {
                    requireContext().toast("Failed to resolve")
                }
            } catch (e: Exception) {
                requireContext().toast("Error: ${e.localizedMessage}")
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

class AlertAdapter(
    private val onResolve: (Alert) -> Unit
) : ListAdapter<Alert, AlertAdapter.AlertViewHolder>(object : DiffUtil.ItemCallback<Alert>() {
    override fun areItemsTheSame(a: Alert, b: Alert) = a.id == b.id
    override fun areContentsTheSame(a: Alert, b: Alert) = a == b
}) {
    inner class AlertViewHolder(private val binding: ItemAlertBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(alert: Alert) {
            val icon = if (alert.type == "critical") "🚨" else "⚠️"
            binding.tvType.text = "$icon ${alert.type.uppercase()}"
            binding.tvToilet.text = "🚻 ${alert.toilet}"
            binding.tvIssue.text = alert.issue
            binding.tvTime.text = "🕐 ${alert.time}"
            val typeColor = if (alert.type == "critical")
                android.graphics.Color.parseColor("#F44336")
            else android.graphics.Color.parseColor("#FF9800")
            binding.tvType.setTextColor(typeColor)
            binding.btnResolve.setOnClickListener { onResolve(alert) }
        }
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlertViewHolder {
        val binding = ItemAlertBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return AlertViewHolder(binding)
    }
    override fun onBindViewHolder(holder: AlertViewHolder, position: Int) = holder.bind(getItem(position))
}
