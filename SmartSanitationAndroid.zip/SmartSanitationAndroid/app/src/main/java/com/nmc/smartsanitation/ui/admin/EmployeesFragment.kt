package com.nmc.smartsanitation.ui.admin

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.nmc.smartsanitation.api.RetrofitClient
import com.nmc.smartsanitation.api.models.Employee
import com.nmc.smartsanitation.databinding.FragmentEmployeesBinding
import com.nmc.smartsanitation.databinding.ItemEmployeeBinding
import com.nmc.smartsanitation.utils.SessionManager
import com.nmc.smartsanitation.utils.hide
import com.nmc.smartsanitation.utils.show
import com.nmc.smartsanitation.utils.toast
import kotlinx.coroutines.launch

class EmployeesFragment : Fragment() {

    private var _binding: FragmentEmployeesBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: EmployeeAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentEmployeesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = EmployeeAdapter()
        binding.rvEmployees.layoutManager = LinearLayoutManager(requireContext())
        binding.rvEmployees.adapter = adapter

        binding.swipeRefresh.setOnRefreshListener { loadEmployees() }
        loadEmployees()
    }

    private fun loadEmployees() {
        binding.progressBar.show()
        lifecycleScope.launch {
            try {
                val token = SessionManager.getBearerToken(requireContext())
                val response = RetrofitClient.apiService.getEmployees(token)
                binding.progressBar.hide()
                binding.swipeRefresh.isRefreshing = false
                if (response.isSuccessful) {
                    val employees = response.body()?.employees ?: emptyList()
                    adapter.submitList(employees)
                    val compliant = employees.count { it.compliant }
                    binding.tvSummary.text = "Staff: ${employees.size} total  ✅ $compliant compliant  ❌ ${employees.size - compliant} non-compliant"
                } else {
                    requireContext().toast("Failed to load employees")
                }
            } catch (e: Exception) {
                binding.progressBar.hide()
                binding.swipeRefresh.isRefreshing = false
                requireContext().toast("Error: ${e.localizedMessage}")
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

class EmployeeAdapter : ListAdapter<Employee, EmployeeAdapter.EmpViewHolder>(
    object : DiffUtil.ItemCallback<Employee>() {
        override fun areItemsTheSame(a: Employee, b: Employee) = a.id == b.id
        override fun areContentsTheSame(a: Employee, b: Employee) = a == b
    }
) {
    inner class EmpViewHolder(private val binding: ItemEmployeeBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(e: Employee) {
            binding.tvName.text = e.name
            binding.tvEmail.text = e.email
            binding.tvArea.text = "📍 ${e.area}"
            binding.tvUploads.text = "📤 ${e.uploads} uploads"
            binding.tvLastUpload.text = "🕐 ${e.lastUpload.ifEmpty { "Never" }}"
            val compIcon = if (e.compliant) "✅ Compliant" else "❌ Non-compliant"
            binding.tvCompliant.text = compIcon
            binding.tvCompliant.setTextColor(
                if (e.compliant) android.graphics.Color.parseColor("#4CAF50")
                else android.graphics.Color.parseColor("#F44336")
            )
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EmpViewHolder {
        val binding = ItemEmployeeBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return EmpViewHolder(binding)
    }

    override fun onBindViewHolder(holder: EmpViewHolder, position: Int) {
        holder.bind(getItem(position))
    }
}
