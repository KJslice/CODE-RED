package com.nmc.smartsanitation.ui.public_view

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.view.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.nmc.smartsanitation.R
import com.nmc.smartsanitation.api.RetrofitClient
import com.nmc.smartsanitation.api.models.Toilet
import com.nmc.smartsanitation.databinding.FragmentNearbyBinding
import com.nmc.smartsanitation.utils.hide
import com.nmc.smartsanitation.utils.show
import com.nmc.smartsanitation.utils.toast
import kotlinx.coroutines.launch

class NearbyFragment : Fragment(), OnMapReadyCallback {

    private var _binding: FragmentNearbyBinding? = null
    private val binding get() = _binding!!

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var googleMap: GoogleMap? = null
    private lateinit var adapter: ToiletAdapter

    // Default: Nagpur center
    private var currentLat = 21.1458
    private var currentLng = 79.0882

    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) getLocationAndLoad() else loadNearby(currentLat, currentLng)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentNearbyBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireActivity())

        // Map setup
        val mapFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        adapter = ToiletAdapter { toilet ->
            val action = NearbyFragmentDirections
                .actionNearbyFragmentToToiletDetailFragment(toilet.id)
            findNavController().navigate(action)
        }
        binding.rvNearby.layoutManager = LinearLayoutManager(requireContext())
        binding.rvNearby.adapter = adapter

        requestLocationPermission()
    }

    private fun requestLocationPermission() {
        val fineGranted = ContextCompat.checkSelfPermission(
            requireContext(), Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (fineGranted) {
            getLocationAndLoad()
        } else {
            locationPermissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    private fun getLocationAndLoad() {
        try {
            fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
                if (location != null) {
                    currentLat = location.latitude
                    currentLng = location.longitude
                }
                loadNearby(currentLat, currentLng)
                googleMap?.moveCamera(
                    CameraUpdateFactory.newLatLngZoom(LatLng(currentLat, currentLng), 14f)
                )
            }
        } catch (e: SecurityException) {
            loadNearby(currentLat, currentLng)
        }
    }

    private fun loadNearby(lat: Double, lng: Double) {
        binding.progressBar.show()
        lifecycleScope.launch {
            try {
                val response = RetrofitClient.apiService.getNearbyToilets(lat, lng)
                binding.progressBar.hide()
                if (response.isSuccessful) {
                    val toilets = response.body()?.ourToilets ?: emptyList()
                    adapter.submitList(toilets)
                    addMapMarkers(toilets)
                    if (toilets.isEmpty()) {
                        requireContext().toast("No toilets found nearby")
                    }
                } else {
                    requireContext().toast("Failed to fetch nearby toilets")
                }
            } catch (e: Exception) {
                binding.progressBar.hide()
                requireContext().toast("Error: ${e.localizedMessage}")
            }
        }
    }

    private fun addMapMarkers(toilets: List<Toilet>) {
        googleMap?.clear()
        toilets.forEach { toilet ->
            val color = when (toilet.grade) {
                "A" -> BitmapDescriptorFactory.HUE_GREEN
                "B" -> BitmapDescriptorFactory.HUE_YELLOW
                "C" -> BitmapDescriptorFactory.HUE_ORANGE
                else -> BitmapDescriptorFactory.HUE_RED
            }
            googleMap?.addMarker(
                MarkerOptions()
                    .position(LatLng(toilet.lat, toilet.lng))
                    .title(toilet.name)
                    .snippet("Grade ${toilet.grade} · ${toilet.distanceText}")
                    .icon(BitmapDescriptorFactory.defaultMarker(color))
            )
        }
        if (toilets.isNotEmpty()) {
            val first = toilets.first()
            googleMap?.animateCamera(
                CameraUpdateFactory.newLatLngZoom(LatLng(first.lat, first.lng), 13f)
            )
        }
    }

    override fun onMapReady(map: GoogleMap) {
        googleMap = map
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(LatLng(currentLat, currentLng), 13f))
        try {
            val granted = ContextCompat.checkSelfPermission(
                requireContext(), Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
            map.isMyLocationEnabled = granted
        } catch (_: SecurityException) {}
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
