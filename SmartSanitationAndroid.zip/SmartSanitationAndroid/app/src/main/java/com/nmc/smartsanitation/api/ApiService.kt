package com.nmc.smartsanitation.api

import com.nmc.smartsanitation.api.models.*
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.*

interface ApiService {

    // ── Auth ──────────────────────────────────────────────────────────────────

    @POST("api/auth/login")
    suspend fun login(@Body request: LoginRequest): Response<LoginResponse>

    @POST("api/auth/logout")
    suspend fun logout(@Header("Authorization") token: String): Response<MessageResponse>

    // ── Toilets ───────────────────────────────────────────────────────────────

    @GET("api/toilets")
    suspend fun getToilets(
        @Query("grade") grade: String? = null,
        @Query("status") status: String? = null,
        @Query("area") area: String? = null
    ): Response<ToiletsResponse>

    @GET("api/toilets/{id}")
    suspend fun getToilet(@Path("id") id: Int): Response<Toilet>

    @POST("api/toilets/{id}/rate")
    suspend fun rateToilet(
        @Path("id") id: Int,
        @Body request: RatingRequest
    ): Response<RatingResponse>

    @GET("api/toilets/nearby")
    suspend fun getNearbyToilets(
        @Query("lat") lat: Double,
        @Query("lng") lng: Double,
        @Query("radius") radius: Int = 2000
    ): Response<NearbyResponse>

    // ── Upload ────────────────────────────────────────────────────────────────

    @Multipart
    @POST("api/upload/photos")
    suspend fun uploadPhotos(
        @Header("Authorization") token: String,
        @Part("toilet_id") toiletId: RequestBody,
        @Part photos: List<MultipartBody.Part>
    ): Response<UploadResponse>

    // ── Admin: Pending Uploads ─────────────────────────────────────────────────

    @GET("api/uploads/pending")
    suspend fun getPendingUploads(
        @Header("Authorization") token: String
    ): Response<PendingUploadsResponse>

    @POST("api/uploads/{id}/approve")
    suspend fun approveUpload(
        @Header("Authorization") token: String,
        @Path("id") id: String
    ): Response<MessageResponse>

    @POST("api/uploads/{id}/reject")
    suspend fun rejectUpload(
        @Header("Authorization") token: String,
        @Path("id") id: String,
        @Body request: RejectRequest
    ): Response<MessageResponse>

    // ── Admin: Alerts ─────────────────────────────────────────────────────────

    @GET("api/alerts")
    suspend fun getAlerts(
        @Header("Authorization") token: String
    ): Response<AlertsResponse>

    @POST("api/alerts/{id}/resolve")
    suspend fun resolveAlert(
        @Header("Authorization") token: String,
        @Path("id") id: String
    ): Response<MessageResponse>

    // ── Admin: Employees ──────────────────────────────────────────────────────

    @GET("api/employees")
    suspend fun getEmployees(
        @Header("Authorization") token: String
    ): Response<EmployeesResponse>

    @GET("api/admin/stats")
    suspend fun getAdminStats(
        @Header("Authorization") token: String
    ): Response<AdminStats>

    // ── Public Display ────────────────────────────────────────────────────────

    @GET("api/display")
    suspend fun getDisplayData(): Response<DisplayResponse>
}
