package com.nmc.smartsanitation.ui.admin

import android.os.Bundle
import android.view.*
import androidx.core.view.MenuHost
import androidx.core.view.MenuProvider
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.nmc.smartsanitation.MainActivity
import com.nmc.smartsanitation.R
import com.nmc.smartsanitation.api.RetrofitClient
import com.nmc.smartsanitation.databinding.FragmentAdminDashboardBinding
import com.nmc.smartsanitation.utils.SessionManager
import com.nmc.smartsanitation.utils.hide
import com.nmc.smartsanitation.utils.show
import com.nmc.smartsanitation.utils.toast
import kotlinx.coroutines.launch

class AdminDashboardFragment : Fragment() {

    private var _binding: FragmentAdminDashboardBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAdminDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupMenu()

        binding.tvWelcome.text = "Admin: ${SessionManager.getName(requireContext())} 🛡️"

        loadStats()

        binding.btnPendingUploads.setOnClickListener {
            findNavController().navigate(R.id.pendingUploadsFragment)
        }
        binding.btnAlerts.setOnClickListener {
            findNavController().navigate(R.id.alertsFragment)
        }
        binding.btnEmployees.setOnClickListener {
            findNavController().navigate(R.id.employeesFragment)
        }
        binding.swipeRefresh.setOnRefreshListener { loadStats() }
    }

    private fun loadStats() {
        binding.progressBar.show()
        lifecycleScope.launch {
            try {
                val token = SessionManager.getBearerToken(requireContext())
                val response = RetrofitClient.apiService.getAdminStats(token)
                binding.progressBar.hide()
                binding.swipeRefresh.isRefreshing = false

                if (response.isSuccessful) {
                    val s = response.body() ?: return@launch
                    binding.tvTotalToilets.text = "${s.totalToilets}"
                    binding.tvAvgScore.text = "${s.avgScore}"
                    binding.tvPending.text = "${s.pendingReviews}"
                    binding.tvAlerts.text = "${s.activeAlerts}"
                    binding.tvCompliant.text = "${s.compliantStaff}/${s.totalEmployees}"
                    binding.tvOpenToilets.text = "${s.openToilets}/${s.totalToilets}"
                    val gc = s.gradeCounts
                    binding.tvGrades.text = "A:${gc["A"]?:0}  B:${gc["B"]?:0}  C:${gc["C"]?:0}  D:${gc["D"]?:0}"
                } else {
                    requireContext().toast("Failed to load stats")
                }
            } catch (e: Exception) {
                binding.progressBar.hide()
                binding.swipeRefresh.isRefreshing = false
                requireContext().toast("Error: ${e.localizedMessage}")
            }
        }
    }

    private fun setupMenu() {
        val menuHost: MenuHost = requireActivity()
        menuHost.addMenuProvider(object : MenuProvider {
            override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
                menuInflater.inflate(R.menu.menu_logout_only, menu)
            }
            override fun onMenuItemSelected(item: MenuItem): Boolean {
                return if (item.itemId == R.id.action_logout) {
                    (activity as? MainActivity)?.logout(); true
                } else false
            }
        }, viewLifecycleOwner, Lifecycle.State.RESUMED)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
