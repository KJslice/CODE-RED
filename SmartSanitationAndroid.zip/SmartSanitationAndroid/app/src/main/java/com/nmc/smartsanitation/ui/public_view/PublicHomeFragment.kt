package com.nmc.smartsanitation.ui.public_view

import android.os.Bundle
import android.view.*
import androidx.appcompat.widget.SearchView
import androidx.core.view.MenuHost
import androidx.core.view.MenuProvider
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.nmc.smartsanitation.MainActivity
import com.nmc.smartsanitation.R
import com.nmc.smartsanitation.api.RetrofitClient
import com.nmc.smartsanitation.api.models.Toilet
import com.nmc.smartsanitation.databinding.FragmentPublicHomeBinding
import com.nmc.smartsanitation.utils.SessionManager
import com.nmc.smartsanitation.utils.hide
import com.nmc.smartsanitation.utils.show
import com.nmc.smartsanitation.utils.toast
import kotlinx.coroutines.launch

class PublicHomeFragment : Fragment() {

    private var _binding: FragmentPublicHomeBinding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: ToiletAdapter
    private var allToilets: List<Toilet> = emptyList()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPublicHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupMenu()

        binding.tvWelcome.text = "Welcome, ${SessionManager.getName(requireContext())} 👋"

        adapter = ToiletAdapter { toilet ->
            val action = PublicHomeFragmentDirections
                .actionPublicHomeFragmentToToiletDetailFragment(toilet.id)
            findNavController().navigate(action)
        }
        binding.rvToilets.layoutManager = LinearLayoutManager(requireContext())
        binding.rvToilets.adapter = adapter

        binding.swipeRefresh.setOnRefreshListener { loadToilets() }

        // Grade filter chips
        binding.chipAll.isChecked = true
        val chips = listOf(
            binding.chipAll to null,
            binding.chipA   to "A",
            binding.chipB   to "B",
            binding.chipC   to "C",
            binding.chipD   to "D"
        )
        chips.forEach { (chip, grade) ->
            chip.setOnClickListener {
                chips.forEach { (c, _) -> c.isChecked = (c == chip) }
                filterByGrade(grade)
            }
        }

        binding.btnNearby.setOnClickListener {
            findNavController().navigate(R.id.nearbyFragment)
        }

        loadToilets()
    }

    private fun loadToilets() {
        binding.progressBar.show()
        lifecycleScope.launch {
            try {
                val response = RetrofitClient.apiService.getToilets()
                binding.progressBar.hide()
                binding.swipeRefresh.isRefreshing = false
                if (response.isSuccessful) {
                    allToilets = response.body()?.toilets ?: emptyList()
                    adapter.submitList(allToilets)
                    binding.tvCount.text = "${allToilets.size} toilets available"
                } else {
                    requireContext().toast("Failed to load toilets")
                }
            } catch (e: Exception) {
                binding.progressBar.hide()
                binding.swipeRefresh.isRefreshing = false
                requireContext().toast("Error: ${e.localizedMessage}")
            }
        }
    }

    private fun filterByGrade(grade: String?) {
        val filtered = if (grade == null) allToilets
        else allToilets.filter { it.grade.uppercase() == grade }
        adapter.submitList(filtered)
        binding.tvCount.text = "${filtered.size} toilets"
    }

    private fun setupMenu() {
        val menuHost: MenuHost = requireActivity()
        menuHost.addMenuProvider(object : MenuProvider {
            override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
                menuInflater.inflate(R.menu.menu_main_options, menu)
                val searchItem = menu.findItem(R.id.action_search)
                val searchView = searchItem?.actionView as? SearchView
                searchView?.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
                    override fun onQueryTextSubmit(query: String?) = false
                    override fun onQueryTextChange(newText: String?): Boolean {
                        val q = newText?.lowercase().orEmpty()
                        val filtered = allToilets.filter {
                            it.name.lowercase().contains(q) || it.area.lowercase().contains(q)
                        }
                        adapter.submitList(filtered)
                        return true
                    }
                })
            }

            override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
                return when (menuItem.itemId) {
                    R.id.action_logout -> {
                        (activity as? MainActivity)?.logout()
                        true
                    }
                    else -> false
                }
            }
        }, viewLifecycleOwner, Lifecycle.State.RESUMED)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
