package com.nmc.smartsanitation.ui.employee

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.nmc.smartsanitation.databinding.FragmentUploadPhotosBinding
import com.nmc.smartsanitation.api.RetrofitClient
import com.nmc.smartsanitation.utils.SessionManager
import com.nmc.smartsanitation.utils.gradeColor
import com.nmc.smartsanitation.utils.hide
import com.nmc.smartsanitation.utils.show
import com.nmc.smartsanitation.utils.toast
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.io.FileOutputStream

class UploadPhotosFragment : Fragment() {

    private var _binding: FragmentUploadPhotosBinding? = null
    private val binding get() = _binding!!

    private val selectedUris = mutableListOf<Uri>()

    private val pickImages = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        if (uris.isNotEmpty()) {
            selectedUris.clear()
            selectedUris.addAll(uris.take(6))
            binding.tvPhotosSelected.text = "${selectedUris.size} photo(s) selected"
            binding.btnUpload.isEnabled = true

            // Show first image as preview
            if (selectedUris.isNotEmpty()) {
                binding.imgPreview.setImageURI(selectedUris.first())
                binding.imgPreview.show()
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentUploadPhotosBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnSelectPhotos.setOnClickListener {
            pickImages.launch("image/*")
        }

        binding.btnUpload.isEnabled = false
        binding.btnUpload.setOnClickListener { uploadPhotos() }

        // Pre-populate toilet IDs for selection (1-8 as per seed data)
        val toiletItems = (1..8).map { "Toilet #$it" }.toTypedArray()
        binding.spinnerToilet.adapter = android.widget.ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            toiletItems
        )
    }

    private fun uploadPhotos() {
        if (selectedUris.isEmpty()) {
            requireContext().toast("Please select photos first")
            return
        }

        val toiletId = (binding.spinnerToilet.selectedItemPosition + 1).toString()
        val token = SessionManager.getBearerToken(requireContext())

        binding.progressBar.show()
        binding.btnUpload.isEnabled = false
        binding.tvStatus.text = "Uploading and analyzing... ⏳"
        binding.tvStatus.show()
        binding.cardResult.hide()

        lifecycleScope.launch {
            try {
                val parts = selectedUris.mapIndexed { index, uri ->
                    val inputStream = requireContext().contentResolver.openInputStream(uri)
                    val file = File(requireContext().cacheDir, "photo_$index.jpg")
                    FileOutputStream(file).use { output ->
                        inputStream?.copyTo(output)
                    }
                    val requestFile = file.asRequestBody("image/jpeg".toMediaTypeOrNull())
                    MultipartBody.Part.createFormData("photos", file.name, requestFile)
                }

                val toiletIdBody = toiletId.toRequestBody("text/plain".toMediaTypeOrNull())

                val response = RetrofitClient.apiService.uploadPhotos(token, toiletIdBody, parts)

                binding.progressBar.hide()

                if (response.isSuccessful) {
                    val result = response.body()
                    val ai = result?.aiResult
                    if (ai != null) {
                        binding.tvScore.text = "Score: ${ai.score}/100"
                        binding.tvGradeResult.text = "Grade: ${ai.grade}"
                        binding.tvGradeResult.setTextColor(gradeColor(ai.grade))

                        val issueText = if (ai.issues.isEmpty()) "No issues detected ✅"
                        else ai.issues.joinToString("\n") { "• ${it.icon} ${it.issueClass} (-${it.deduction})" }
                        binding.tvIssues.text = issueText

                        binding.tvUrgent.text = if (result.urgent) "🚨 URGENT – Admin notified!" else "✅ Sent for admin review"
                        binding.cardResult.show()
                        binding.tvStatus.hide()

                        // Reset
                        selectedUris.clear()
                        binding.tvPhotosSelected.text = "No photos selected"
                        binding.imgPreview.hide()
                    }
                } else {
                    binding.tvStatus.text = "Upload failed. Please try again."
                    requireContext().toast("Upload failed")
                }
                binding.btnUpload.isEnabled = true
            } catch (e: Exception) {
                binding.progressBar.hide()
                binding.btnUpload.isEnabled = true
                binding.tvStatus.text = "Error: ${e.localizedMessage}"
                requireContext().toast("Error: ${e.localizedMessage}")
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
