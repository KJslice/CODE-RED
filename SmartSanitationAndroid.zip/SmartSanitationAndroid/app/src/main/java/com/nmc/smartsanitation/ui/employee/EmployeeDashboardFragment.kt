package com.nmc.smartsanitation.ui.employee

import android.os.Bundle
import android.view.*
import androidx.core.view.MenuHost
import androidx.core.view.MenuProvider
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.navigation.fragment.findNavController
import com.nmc.smartsanitation.MainActivity
import com.nmc.smartsanitation.R
import com.nmc.smartsanitation.databinding.FragmentEmployeeDashboardBinding
import com.nmc.smartsanitation.utils.SessionManager

class EmployeeDashboardFragment : Fragment() {

    private var _binding: FragmentEmployeeDashboardBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentEmployeeDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupMenu()

        val name = SessionManager.getName(requireContext())
        val area = SessionManager.getArea(requireContext())
        binding.tvWelcome.text = "Welcome, $name 👋"
        binding.tvArea.text = if (area.isNotEmpty()) "Assigned Area: $area" else ""

        binding.btnUploadPhotos.setOnClickListener {
            findNavController().navigate(R.id.uploadPhotosFragment)
        }

        binding.btnViewToilets.setOnClickListener {
            findNavController().navigate(R.id.publicHomeFragment)
        }
    }

    private fun setupMenu() {
        val menuHost: MenuHost = requireActivity()
        menuHost.addMenuProvider(object : MenuProvider {
            override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
                menuInflater.inflate(R.menu.menu_logout_only, menu)
            }
            override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
                return if (menuItem.itemId == R.id.action_logout) {
                    (activity as? MainActivity)?.logout(); true
                } else false
            }
        }, viewLifecycleOwner, Lifecycle.State.RESUMED)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
