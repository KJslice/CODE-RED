package com.nmc.smartsanitation.utils

import android.content.Context
import android.view.View
import android.widget.Toast
import com.google.android.material.color.MaterialColors
import com.google.android.material.snackbar.Snackbar

fun View.show() { visibility = View.VISIBLE }
fun View.hide() { visibility = View.GONE }
fun View.invisible() { visibility = View.INVISIBLE }

fun Context.toast(msg: String) {
    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}

fun View.snack(msg: String, actionLabel: String? = null, action: (() -> Unit)? = null) {
    val sb = Snackbar.make(this, msg, Snackbar.LENGTH_LONG)
    if (actionLabel != null && action != null) {
        sb.setAction(actionLabel) { action() }
    }
    sb.show()
}

fun gradeColor(grade: String): Int = when (grade.uppercase()) {
    "A" -> android.graphics.Color.parseColor("#4CAF50")  // green
    "B" -> android.graphics.Color.parseColor("#8BC34A")  // light green
    "C" -> android.graphics.Color.parseColor("#FF9800")  // orange
    else -> android.graphics.Color.parseColor("#F44336") // red
}

fun scoreEmoji(score: Int): String = when {
    score >= 90 -> "🌟"
    score >= 75 -> "✅"
    score >= 60 -> "⚠️"
    else        -> "🚨"
}
