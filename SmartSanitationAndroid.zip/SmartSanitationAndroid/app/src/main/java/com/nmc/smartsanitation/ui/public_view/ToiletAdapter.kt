package com.nmc.smartsanitation.ui.public_view

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.nmc.smartsanitation.api.models.Toilet
import com.nmc.smartsanitation.databinding.ItemToiletBinding
import com.nmc.smartsanitation.utils.gradeColor
import com.nmc.smartsanitation.utils.scoreEmoji

class ToiletAdapter(
    private val onClick: (Toilet) -> Unit
) : ListAdapter<Toilet, ToiletAdapter.ToiletViewHolder>(DIFF) {

    inner class ToiletViewHolder(private val binding: ItemToiletBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(toilet: Toilet) {
            binding.tvName.text = toilet.name
            binding.tvArea.text = toilet.area
            binding.tvScore.text = "${scoreEmoji(toilet.score)} ${toilet.score}/100"
            binding.tvGrade.text = "Grade ${toilet.grade}"
            binding.tvGrade.setTextColor(gradeColor(toilet.grade))
            binding.tvStatus.text = toilet.status
            binding.tvRating.text = "⭐ ${toilet.rating} (${toilet.reviews} reviews)"
            binding.tvFacilities.text = "🚻 Gents: ${toilet.gents}  Ladies: ${toilet.ladies}" +
                    if (toilet.divyang) "  ♿ Divyang" else ""

            if (toilet.distanceText.isNotEmpty()) {
                binding.tvDistance.text = "📍 ${toilet.distanceText}"
            } else {
                binding.tvDistance.text = ""
            }

            if (toilet.alert) {
                binding.tvAlert.text = "⚠️ Alert"
                binding.tvAlert.visibility = android.view.View.VISIBLE
            } else {
                binding.tvAlert.visibility = android.view.View.GONE
            }

            // Grade background tint
            val color = gradeColor(toilet.grade)
            binding.tvGrade.background?.setTint(color)

            binding.root.setOnClickListener { onClick(toilet) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ToiletViewHolder {
        val binding = ItemToiletBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ToiletViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ToiletViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Toilet>() {
            override fun areItemsTheSame(a: Toilet, b: Toilet) = a.id == b.id
            override fun areContentsTheSame(a: Toilet, b: Toilet) = a == b
        }
    }
}
