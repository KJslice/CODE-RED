package com.nmc.smartsanitation.api.models

import com.google.gson.annotations.SerializedName

// ── Auth ─────────────────────────────────────────────────────────────────────

data class LoginRequest(
    val role: String,
    val email: String = "",
    val password: String = ""
)

data class LoginResponse(
    val token: String?,
    val role: String?,
    val name: String?,
    val email: String?,
    val area: String?,
    val id: String?,
    val error: String?
)

// ── Toilet ───────────────────────────────────────────────────────────────────

data class Toilet(
    val id: Int = 0,
    val name: String = "",
    val area: String = "",
    val address: String = "",
    val lat: Double = 0.0,
    val lng: Double = 0.0,
    val score: Int = 0,
    val grade: String = "D",
    val status: String = "Closed",
    val rating: Double = 0.0,
    val reviews: Int = 0,
    val gents: Int = 0,
    val ladies: Int = 0,
    val divyang: Boolean = false,
    @SerializedName("last_cleaned") val lastCleaned: String = "",
    val issues: List<String> = emptyList(),
    val alert: Boolean = false,
    @SerializedName("distance_text") val distanceText: String = "",
    @SerializedName("duration_text") val durationText: String = "",
    @SerializedName("directions_url") val directionsUrl: String = ""
)

data class ToiletsResponse(
    val toilets: List<Toilet>,
    val count: Int
)

data class NearbyResponse(
    @SerializedName("our_toilets") val ourToilets: List<Toilet>,
    @SerializedName("google_places") val googlePlaces: List<Any>
)

data class RatingRequest(val rating: Float)

data class RatingResponse(val rating: Double, val reviews: Int)

// ── Upload ────────────────────────────────────────────────────────────────────

data class AiIssue(
    @SerializedName("class") val issueClass: String = "",
    val deduction: Int = 0,
    val icon: String = ""
)

data class AiResult(
    val score: Int = 0,
    val grade: String = "D",
    val issues: List<AiIssue> = emptyList(),
    @SerializedName("processing_time_ms") val processingTimeMs: Int = 0
)

data class UploadResponse(
    @SerializedName("upload_id") val uploadId: String = "",
    @SerializedName("ai_result") val aiResult: AiResult = AiResult(),
    val urgent: Boolean = false,
    val message: String = ""
)

// ── Admin: Pending Uploads ────────────────────────────────────────────────────

data class PendingUpload(
    val id: String = "",
    val toiletId: Int = 0,
    val staffName: String = "",
    val uploadedAt: String = "",
    val aiScore: Int = 0,
    val aiGrade: String = "D",
    val issues: List<String> = emptyList(),
    val status: String = "pending",
    val photos: Int = 0,
    val urgent: Boolean = false,
    val processingMs: Int = 0
)

data class PendingUploadsResponse(
    val uploads: List<PendingUpload>,
    val count: Int
)

data class RejectRequest(val reason: String)

data class MessageResponse(val message: String)

// ── Admin: Alerts ─────────────────────────────────────────────────────────────

data class Alert(
    val id: String = "",
    val type: String = "warning",
    val toilet: String = "",
    val toiletId: Int = 0,
    val issue: String = "",
    val time: String = "",
    val resolved: Boolean = false
)

data class AlertsResponse(
    val alerts: List<Alert>,
    val count: Int
)

// ── Admin: Employees ──────────────────────────────────────────────────────────

data class Employee(
    val id: String = "",
    val name: String = "",
    val email: String = "",
    val area: String = "",
    val compliant: Boolean = false,
    val lastUpload: String = "",
    val uploads: Int = 0
)

data class EmployeesResponse(val employees: List<Employee>)

// ── Admin: Stats ──────────────────────────────────────────────────────────────

data class AdminStats(
    @SerializedName("total_toilets") val totalToilets: Int = 0,
    @SerializedName("grade_counts") val gradeCounts: Map<String, Int> = emptyMap(),
    @SerializedName("avg_score") val avgScore: Double = 0.0,
    @SerializedName("pending_reviews") val pendingReviews: Int = 0,
    @SerializedName("active_alerts") val activeAlerts: Int = 0,
    @SerializedName("total_employees") val totalEmployees: Int = 0,
    @SerializedName("compliant_staff") val compliantStaff: Int = 0,
    @SerializedName("non_compliant_staff") val nonCompliantStaff: Int = 0,
    @SerializedName("toilets_with_alert") val toiletsWithAlert: Int = 0,
    @SerializedName("open_toilets") val openToilets: Int = 0
)

// ── Display Board ─────────────────────────────────────────────────────────────

data class DisplayStats(
    @SerializedName("avg_score") val avgScore: Double = 0.0,
    @SerializedName("open_count") val openCount: Int = 0,
    val total: Int = 0,
    @SerializedName("grade_A_count") val gradeACount: Int = 0
)

data class DisplayResponse(
    @SerializedName("top_toilets") val topToilets: List<Toilet>,
    val stats: DisplayStats,
    @SerializedName("map_url") val mapUrl: String,
    @SerializedName("updated_at") val updatedAt: String
)
