package com.nmc.smartsanitation.utils

import android.content.Context
import android.content.SharedPreferences

object SessionManager {

    private const val PREF_NAME = "smart_sanitation_prefs"
    private const val KEY_TOKEN = "auth_token"
    private const val KEY_ROLE = "user_role"
    private const val KEY_NAME = "user_name"
    private const val KEY_EMAIL = "user_email"
    private const val KEY_AREA = "user_area"

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    fun saveSession(
        context: Context,
        token: String,
        role: String,
        name: String,
        email: String = "",
        area: String = ""
    ) {
        prefs(context).edit()
            .putString(KEY_TOKEN, token)
            .putString(KEY_ROLE, role)
            .putString(KEY_NAME, name)
            .putString(KEY_EMAIL, email)
            .putString(KEY_AREA, area)
            .apply()
    }

    fun getToken(context: Context): String? = prefs(context).getString(KEY_TOKEN, null)

    fun getRole(context: Context): String = prefs(context).getString(KEY_ROLE, "") ?: ""

    fun getName(context: Context): String = prefs(context).getString(KEY_NAME, "User") ?: "User"

    fun getEmail(context: Context): String = prefs(context).getString(KEY_EMAIL, "") ?: ""

    fun getArea(context: Context): String = prefs(context).getString(KEY_AREA, "") ?: ""

    fun getBearerToken(context: Context): String = "Bearer ${getToken(context)}"

    fun isLoggedIn(context: Context): Boolean = getToken(context) != null

    fun clearSession(context: Context) {
        prefs(context).edit().clear().apply()
    }
}
