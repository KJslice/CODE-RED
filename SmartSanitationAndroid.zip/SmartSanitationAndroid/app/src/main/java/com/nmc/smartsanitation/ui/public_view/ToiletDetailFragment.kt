package com.nmc.smartsanitation.ui.public_view

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.*
import android.widget.RatingBar
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.navArgs
import com.nmc.smartsanitation.api.RetrofitClient
import com.nmc.smartsanitation.api.models.RatingRequest
import com.nmc.smartsanitation.databinding.FragmentToiletDetailBinding
import com.nmc.smartsanitation.utils.gradeColor
import com.nmc.smartsanitation.utils.hide
import com.nmc.smartsanitation.utils.scoreEmoji
import com.nmc.smartsanitation.utils.show
import com.nmc.smartsanitation.utils.toast
import kotlinx.coroutines.launch

class ToiletDetailFragment : Fragment() {

    private var _binding: FragmentToiletDetailBinding? = null
    private val binding get() = _binding!!
    private val args: ToiletDetailFragmentArgs by navArgs()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentToiletDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        loadToilet(args.toiletId)
    }

    private fun loadToilet(id: Int) {
        binding.progressBar.show()
        lifecycleScope.launch {
            try {
                val response = RetrofitClient.apiService.getToilet(id)
                binding.progressBar.hide()
                if (response.isSuccessful) {
                    val t = response.body() ?: return@launch
                    binding.tvName.text = t.name
                    binding.tvAddress.text = "📍 ${t.address}"
                    binding.tvArea.text = t.area
                    binding.tvScore.text = "${scoreEmoji(t.score)} Score: ${t.score}/100"
                    binding.tvGrade.text = "Grade ${t.grade}"
                    binding.tvGrade.setTextColor(gradeColor(t.grade))
                    binding.tvStatus.text = "Status: ${t.status}"
                    binding.tvLastCleaned.text = "🧹 Last cleaned: ${t.lastCleaned}"
                    binding.tvFacilities.text =
                        "🚻 Gents: ${t.gents}  Ladies: ${t.ladies}" +
                        if (t.divyang) "  ♿ Divyang" else ""
                    binding.tvRating.text = "⭐ ${t.rating} (${t.reviews} reviews)"

                    if (t.issues.isNotEmpty()) {
                        binding.tvIssues.text = "⚠️ Issues: ${t.issues.joinToString(", ")}"
                        binding.tvIssues.show()
                    } else {
                        binding.tvIssues.text = "✅ No issues reported"
                        binding.tvIssues.show()
                    }

                    // Directions button
                    binding.btnDirections.setOnClickListener {
                        val url = t.directionsUrl.ifEmpty {
                            "https://maps.google.com/?q=${t.lat},${t.lng}"
                        }
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                    }

                    // Rating submission
                    binding.ratingBar.rating = t.rating.toFloat()
                    binding.btnSubmitRating.setOnClickListener {
                        submitRating(t.id, binding.ratingBar.rating)
                    }
                } else {
                    requireContext().toast("Failed to load toilet details")
                }
            } catch (e: Exception) {
                binding.progressBar.hide()
                requireContext().toast("Error: ${e.localizedMessage}")
            }
        }
    }

    private fun submitRating(toiletId: Int, rating: Float) {
        if (rating < 1f) {
            requireContext().toast("Please select a rating")
            return
        }
        lifecycleScope.launch {
            try {
                val response = RetrofitClient.apiService.rateToilet(
                    toiletId, RatingRequest(rating)
                )
                if (response.isSuccessful) {
                    val r = response.body()
                    requireContext().toast("Thanks! New rating: ${r?.rating} ⭐")
                    binding.tvRating.text = "⭐ ${r?.rating} (${r?.reviews} reviews)"
                } else {
                    requireContext().toast("Could not submit rating")
                }
            } catch (e: Exception) {
                requireContext().toast("Error: ${e.localizedMessage}")
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
