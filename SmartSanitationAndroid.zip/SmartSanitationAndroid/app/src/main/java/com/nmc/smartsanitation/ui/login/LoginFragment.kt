package com.nmc.smartsanitation.ui.login

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.nmc.smartsanitation.MainActivity
import com.nmc.smartsanitation.api.RetrofitClient
import com.nmc.smartsanitation.api.models.LoginRequest
import com.nmc.smartsanitation.databinding.FragmentLoginBinding
import com.nmc.smartsanitation.utils.SessionManager
import com.nmc.smartsanitation.utils.hide
import com.nmc.smartsanitation.utils.show
import com.nmc.smartsanitation.utils.toast
import kotlinx.coroutines.launch

class LoginFragment : Fragment() {

    private var _binding: FragmentLoginBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLoginBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Default: public login
        binding.rgRole.check(binding.rbPublic.id)
        updateFieldVisibility("public")

        binding.rgRole.setOnCheckedChangeListener { _, checkedId ->
            val role = when (checkedId) {
                binding.rbPublic.id   -> "public"
                binding.rbEmployee.id -> "employee"
                binding.rbAdmin.id    -> "admin"
                else                  -> "public"
            }
            updateFieldVisibility(role)
        }

        binding.btnLogin.setOnClickListener { doLogin() }
    }

    private fun updateFieldVisibility(role: String) {
        if (role == "public") {
            binding.tilEmail.hide()
            binding.tilPassword.hide()
        } else {
            binding.tilEmail.show()
            binding.tilPassword.show()
        }
    }

    private fun doLogin() {
        val role = when (binding.rgRole.checkedRadioButtonId) {
            binding.rbEmployee.id -> "employee"
            binding.rbAdmin.id    -> "admin"
            else                  -> "public"
        }
        val email    = binding.etEmail.text.toString().trim()
        val password = binding.etPassword.text.toString()

        if (role != "public") {
            if (email.isEmpty()) { binding.tilEmail.error = "Required"; return }
            if (password.isEmpty()) { binding.tilPassword.error = "Required"; return }
        }

        binding.progressBar.show()
        binding.btnLogin.isEnabled = false

        lifecycleScope.launch {
            try {
                val response = RetrofitClient.apiService.login(
                    LoginRequest(role = role, email = email, password = password)
                )
                binding.progressBar.hide()
                binding.btnLogin.isEnabled = true

                if (response.isSuccessful) {
                    val body = response.body()
                    if (body?.token != null) {
                        SessionManager.saveSession(
                            requireContext(),
                            token  = body.token,
                            role   = body.role ?: role,
                            name   = body.name ?: "User",
                            email  = body.email ?: email,
                            area   = body.area ?: ""
                        )
                        (activity as? MainActivity)?.navigateByRole(body.role ?: role)
                    } else {
                        requireContext().toast(body?.error ?: "Login failed")
                    }
                } else {
                    requireContext().toast("Invalid credentials")
                }
            } catch (e: Exception) {
                binding.progressBar.hide()
                binding.btnLogin.isEnabled = true
                requireContext().toast("Connection error: ${e.localizedMessage}")
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
