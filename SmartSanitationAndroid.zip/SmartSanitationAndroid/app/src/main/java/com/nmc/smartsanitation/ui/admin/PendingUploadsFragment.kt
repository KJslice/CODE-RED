package com.nmc.smartsanitation.ui.admin

import android.os.Bundle
import android.view.*
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.nmc.smartsanitation.api.RetrofitClient
import com.nmc.smartsanitation.api.models.PendingUpload
import com.nmc.smartsanitation.api.models.RejectRequest
import com.nmc.smartsanitation.databinding.FragmentPendingUploadsBinding
import com.nmc.smartsanitation.utils.SessionManager
import com.nmc.smartsanitation.utils.gradeColor
import com.nmc.smartsanitation.utils.hide
import com.nmc.smartsanitation.utils.show
import com.nmc.smartsanitation.utils.toast
import kotlinx.coroutines.launch

class PendingUploadsFragment : Fragment() {

    private var _binding: FragmentPendingUploadsBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: PendingUploadAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPendingUploadsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = PendingUploadAdapter(
            onApprove = { upload -> approveUpload(upload) },
            onReject  = { upload -> showRejectDialog(upload) }
        )
        binding.rvUploads.layoutManager = LinearLayoutManager(requireContext())
        binding.rvUploads.adapter = adapter

        binding.swipeRefresh.setOnRefreshListener { loadUploads() }
        loadUploads()
    }

    private fun loadUploads() {
        binding.progressBar.show()
        lifecycleScope.launch {
            try {
                val token = SessionManager.getBearerToken(requireContext())
                val response = RetrofitClient.apiService.getPendingUploads(token)
                binding.progressBar.hide()
                binding.swipeRefresh.isRefreshing = false
                if (response.isSuccessful) {
                    val uploads = response.body()?.uploads ?: emptyList()
                    adapter.submitList(uploads)
                    binding.tvCount.text = "${uploads.size} pending review(s)"
                    if (uploads.isEmpty()) binding.tvEmpty.show() else binding.tvEmpty.hide()
                } else {
                    requireContext().toast("Failed to load uploads")
                }
            } catch (e: Exception) {
                binding.progressBar.hide()
                binding.swipeRefresh.isRefreshing = false
                requireContext().toast("Error: ${e.localizedMessage}")
            }
        }
    }

    private fun approveUpload(upload: PendingUpload) {
        lifecycleScope.launch {
            try {
                val token = SessionManager.getBearerToken(requireContext())
                val response = RetrofitClient.apiService.approveUpload(token, upload.id)
                if (response.isSuccessful) {
                    requireContext().toast("✅ Approved! Toilet score updated.")
                    loadUploads()
                } else {
                    requireContext().toast("Approval failed")
                }
            } catch (e: Exception) {
                requireContext().toast("Error: ${e.localizedMessage}")
            }
        }
    }

    private fun showRejectDialog(upload: PendingUpload) {
        val input = EditText(requireContext()).apply {
            hint = "Reason for rejection"
        }
        AlertDialog.Builder(requireContext())
            .setTitle("Reject Upload")
            .setMessage("Provide a reason for rejecting ${upload.staffName}'s upload:")
            .setView(input)
            .setPositiveButton("Reject") { _, _ ->
                val reason = input.text.toString().ifEmpty { "No reason given" }
                rejectUpload(upload, reason)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun rejectUpload(upload: PendingUpload, reason: String) {
        lifecycleScope.launch {
            try {
                val token = SessionManager.getBearerToken(requireContext())
                val response = RetrofitClient.apiService.rejectUpload(
                    token, upload.id, RejectRequest(reason)
                )
                if (response.isSuccessful) {
                    requireContext().toast("❌ Rejected.")
                    loadUploads()
                } else {
                    requireContext().toast("Rejection failed")
                }
            } catch (e: Exception) {
                requireContext().toast("Error: ${e.localizedMessage}")
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
