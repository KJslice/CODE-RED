package com.nmc.smartsanitation

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.nmc.smartsanitation.databinding.ActivityMainBinding
import com.nmc.smartsanitation.utils.SessionManager
import com.nmc.smartsanitation.utils.hide
import com.nmc.smartsanitation.utils.show

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var navController: NavController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        navController = navHostFragment.navController

        val appBarConfig = AppBarConfiguration(
            setOf(
                R.id.loginFragment,
                R.id.publicHomeFragment,
                R.id.employeeDashboardFragment,
                R.id.adminDashboardFragment
            )
        )
        setupActionBarWithNavController(navController, appBarConfig)
        binding.bottomNav.setupWithNavController(navController)

        // Show/hide bottom nav based on destination
        navController.addOnDestinationChangedListener { _, destination, _ ->
            when (destination.id) {
                R.id.loginFragment -> {
                    binding.bottomNav.hide()
                    binding.toolbar.hide()
                }
                R.id.publicHomeFragment,
                R.id.nearbyFragment,
                R.id.toiletDetailFragment -> {
                    binding.bottomNav.show()
                    binding.toolbar.show()
                    setupPublicBottomNav()
                }
                R.id.employeeDashboardFragment,
                R.id.uploadPhotosFragment -> {
                    binding.bottomNav.show()
                    binding.toolbar.show()
                    setupEmployeeBottomNav()
                }
                R.id.adminDashboardFragment,
                R.id.pendingUploadsFragment,
                R.id.alertsFragment,
                R.id.employeesFragment -> {
                    binding.bottomNav.show()
                    binding.toolbar.show()
                    setupAdminBottomNav()
                }
                else -> {
                    binding.bottomNav.show()
                    binding.toolbar.show()
                }
            }
        }

        // Navigate to correct start based on saved session
        if (SessionManager.isLoggedIn(this)) {
            navigateByRole(SessionManager.getRole(this))
        }
    }

    private fun setupPublicBottomNav() {
        binding.bottomNav.menu.clear()
        binding.bottomNav.inflateMenu(R.menu.menu_public)
    }

    private fun setupEmployeeBottomNav() {
        binding.bottomNav.menu.clear()
        binding.bottomNav.inflateMenu(R.menu.menu_employee)
    }

    private fun setupAdminBottomNav() {
        binding.bottomNav.menu.clear()
        binding.bottomNav.inflateMenu(R.menu.menu_admin)
    }

    fun navigateByRole(role: String) {
        when (role) {
            "public" -> {
                navController.navigate(R.id.publicHomeFragment)
                setupPublicBottomNav()
            }
            "employee" -> {
                navController.navigate(R.id.employeeDashboardFragment)
                setupEmployeeBottomNav()
            }
            "admin" -> {
                navController.navigate(R.id.adminDashboardFragment)
                setupAdminBottomNav()
            }
        }
    }

    fun logout() {
        SessionManager.clearSession(this)
        navController.navigate(R.id.loginFragment)
        binding.bottomNav.hide()
    }

    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp() || super.onSupportNavigateUp()
    }
}
