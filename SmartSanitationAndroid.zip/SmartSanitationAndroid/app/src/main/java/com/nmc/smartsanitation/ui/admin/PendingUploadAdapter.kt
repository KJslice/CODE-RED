package com.nmc.smartsanitation.ui.admin

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.nmc.smartsanitation.api.models.PendingUpload
import com.nmc.smartsanitation.databinding.ItemPendingUploadBinding
import com.nmc.smartsanitation.utils.gradeColor

class PendingUploadAdapter(
    private val onApprove: (PendingUpload) -> Unit,
    private val onReject:  (PendingUpload) -> Unit
) : ListAdapter<PendingUpload, PendingUploadAdapter.ViewHolder>(DIFF) {

    inner class ViewHolder(private val binding: ItemPendingUploadBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(upload: PendingUpload) {
            binding.tvStaff.text = "👤 ${upload.staffName}"
            binding.tvToilet.text = "🚻 Toilet #${upload.toiletId}"
            binding.tvTime.text = "🕐 ${upload.uploadedAt.take(16).replace("T", " ")}"
            binding.tvScore.text = "Score: ${upload.aiScore}/100"
            binding.tvGrade.text = "Grade ${upload.aiGrade}"
            binding.tvGrade.setTextColor(gradeColor(upload.aiGrade))
            binding.tvPhotos.text = "📷 ${upload.photos} photo(s)"
            binding.tvIssues.text = if (upload.issues.isEmpty()) "No issues"
            else upload.issues.joinToString(", ")

            if (upload.urgent) {
                binding.tvUrgent.text = "🚨 URGENT"
                binding.tvUrgent.visibility = android.view.View.VISIBLE
            } else {
                binding.tvUrgent.visibility = android.view.View.GONE
            }

            binding.btnApprove.setOnClickListener { onApprove(upload) }
            binding.btnReject.setOnClickListener  { onReject(upload) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemPendingUploadBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<PendingUpload>() {
            override fun areItemsTheSame(a: PendingUpload, b: PendingUpload) = a.id == b.id
            override fun areContentsTheSame(a: PendingUpload, b: PendingUpload) = a == b
        }
    }
}
