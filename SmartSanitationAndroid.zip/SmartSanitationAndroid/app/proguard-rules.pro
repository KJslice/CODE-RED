# Add project specific ProGuard rules here.
-keep class com.nmc.smartsanitation.api.models.** { *; }
