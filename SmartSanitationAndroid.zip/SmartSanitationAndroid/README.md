# 📱 Smart Sanitation – Android App
### Nagpur Municipal Corporation · Swachh Bharat Digital Initiative

A native Android app (Kotlin) that connects to the Smart Sanitation Flask backend.

---

## 🏗️ Project Structure

```
SmartSanitationAndroid/
├── app/
│   ├── build.gradle            ← Dependencies (Retrofit, Navigation, Maps, etc.)
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/nmc/smartsanitation/
│       │   ├── MainActivity.kt              ← Single-activity host
│       │   ├── api/
│       │   │   ├── ApiService.kt            ← Retrofit interface (all endpoints)
│       │   │   ├── RetrofitClient.kt        ← OkHttp + Retrofit singleton
│       │   │   └── models/Models.kt         ← All request/response data classes
│       │   ├── ui/
│       │   │   ├── login/LoginFragment.kt
│       │   │   ├── public_view/
│       │   │   │   ├── PublicHomeFragment.kt   ← Toilet list + grade filters
│       │   │   │   ├── ToiletAdapter.kt
│       │   │   │   ├── ToiletDetailFragment.kt  ← Details + star rating
│       │   │   │   └── NearbyFragment.kt        ← Google Map + nearby list
│       │   │   ├── employee/
│       │   │   │   ├── EmployeeDashboardFragment.kt
│       │   │   │   └── UploadPhotosFragment.kt  ← Multi-photo AI upload
│       │   │   └── admin/
│       │   │       ├── AdminDashboardFragment.kt ← KPI stats grid
│       │   │       ├── PendingUploadsFragment.kt ← Approve / Reject
│       │   │       ├── PendingUploadAdapter.kt
│       │   │       ├── AlertsFragment.kt
│       │   │       └── EmployeesFragment.kt
│       │   └── utils/
│       │       ├── SessionManager.kt   ← SharedPreferences auth token
│       │       └── Extensions.kt       ← show/hide/toast/gradeColor helpers
│       └── res/
│           ├── layout/         ← All fragment and item XML layouts
│           ├── navigation/nav_graph.xml  ← Jetpack Navigation
│           ├── menu/           ← Bottom nav + toolbar menus
│           ├── drawable/
│           └── values/         ← colors, strings, themes
├── build.gradle
└── settings.gradle
```

---

## 🚀 Setup & Build

### Step 1 – Open in Android Studio
1. Open **Android Studio Hedgehog (2023.1.1)** or newer
2. File → Open → select the `SmartSanitationAndroid` folder
3. Wait for Gradle sync to complete

### Step 2 – Configure Server URL

Open `app/src/main/java/com/nmc/smartsanitation/api/RetrofitClient.kt` and set `BASE_URL`:

| Scenario | URL |
|---|---|
| Android Emulator → local Flask | `http://10.0.2.2:5000/` |
| Real device on same WiFi | `http://192.168.x.x:5000/` |
| Production server | `https://your-domain.com/` |

### Step 3 – Google Maps API Key

Open `AndroidManifest.xml` and replace `YOUR_GOOGLE_MAPS_API_KEY` with your key:
```xml
<meta-data
    android:name="com.google.android.geo.API_KEY"
    android:value="YOUR_ACTUAL_KEY_HERE" />
```

Get a key at: https://console.cloud.google.com → Maps SDK for Android

### Step 4 – Start the Flask Backend

```bash
cd SmartSanitation          # your Python backend folder
source venv/bin/activate
python app.py               # runs on port 5000
```

### Step 5 – Run the App

- **Emulator:** Click ▶ in Android Studio
- **Real device:** Enable USB debugging, connect via USB, click ▶

---

## 🔐 Login Credentials

| Role | Email | Password |
|------|-------|----------|
| Public | *(no credentials needed)* | — |
| Employee | suresh@nmc.gov.in | emp001 |
| Employee | meena@nmc.gov.in | emp002 |
| Admin | admin@nmc.gov.in | admin123 |
| Admin | priya@nmc.gov.in | admin456 |

---

## ✨ Features by Role

### 🏛️ Public
- Browse all 8 NMC toilets with grade (A-D), score, status, facilities
- Filter by grade (A/B/C/D chips)
- Search by name or area
- View toilet details with rating, last cleaned time, issues
- Submit star rating
- View nearby toilets on **Google Map** with color-coded markers
- Get walking directions via Google Maps

### 👷 Employee
- Dashboard with area assignment
- Select toilet → pick up to 6 photos from gallery
- Upload photos → backend runs AI analysis (OpenCV + TensorFlow)
- See AI result: score, grade, detected issues, urgency flag

### 🛡️ Admin
- KPI stats dashboard: total toilets, avg score, pending reviews, alerts, compliance
- Grade distribution breakdown (A/B/C/D count)
- Pending uploads: approve (updates toilet score live) or reject with reason
- Alerts: view critical/warning alerts, mark resolved
- Employees: compliance status, upload count, last upload time

---

## 🛠️ Tech Stack

| Layer | Technology |
|---|---|
| Language | Kotlin |
| Architecture | Single Activity + Fragments + Navigation Component |
| Networking | Retrofit 2 + OkHttp 4 + Gson |
| Concurrency | Kotlin Coroutines |
| UI | Material Design 3 (MaterialComponents) |
| Maps | Google Maps SDK + Fused Location Provider |
| Image Loading | Glide |
| State | SharedPreferences (session), LiveData |
| Min SDK | API 24 (Android 7.0) |
| Target SDK | API 34 (Android 14) |

---

## 📝 Notes

- `usesCleartextTraffic="true"` is set in manifest for local HTTP dev. Remove for production with HTTPS.
- The Maps fragment in `NearbyFragment` degrades gracefully if location permission is denied (falls back to Nagpur city center).
- Session token is stored in SharedPreferences; clearing app data logs out the user.
